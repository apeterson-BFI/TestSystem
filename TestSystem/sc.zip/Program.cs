﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Mail;

namespace TestSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            // x ^ 2 + 1
            extree reference = new extree(expr_type.plus, 0.0);                 // +
            reference.left = new extree(expr_type.pow, 0.0);                    // ^
            reference.left.left = new extree(expr_type.constant, double.NaN);   // x
            reference.left.right = new extree(expr_type.constant, 2.0);         // 2.0
            reference.right = new extree(expr_type.constant, 1.0);              // 1.0

            // ExprEvolver ev = new ExprEvolver(reference, 1.1, Math.E, (Math.E - 1.1) / 100.0, 10.0, 50000);

            ExprGenr gev = new ExprGenr(reference, 1.1, Math.E, (Math.E - 1.1) / 100.0, 5.0, 300000, 3);
            extree ex = gev.Process_Until_Terminal();

            SmtpClient smtp = new SmtpClient("mail.elkrapidsnet.com");
            MailMessage mm = new MailMessage("apeterson@burnettefoods.com", "anthonypete@gmail.com", "Results: " + DateTime.Now.ToString(), "Error Score: " + gev.best_current_score + " Expr: " + ex.ToString());
            smtp.Send(mm);
        }
    }
}