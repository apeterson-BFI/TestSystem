﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestSystem
{
    public class extree
    {
        public extree left;
        public extree right;
        public expr_type type;
        public double val;
        public bool unary;
        public double score;        // abs of diff at each eval point
        public double difference;   // diff from sq of this and ref at each eval point
        public bool failed;         // divide by zero or complex result encountered in sq eval
        public double complex_score;
        public double true_score;

        public extree()
        {

        }

        public extree(expr_type ty, double v)
        {
            score = double.PositiveInfinity;
            type = ty;
            val = v;
            unary = IsUnary(ty);
        }

        // Return pure +/-, set abs dif
        public void ScoreSqrt(extree sqref, double x_start, double x_end, double x_prec)
        {
            extree this_sqr = new extree(expr_type.compose, 0.0);
            this_sqr.left = this;
            this_sqr.right = this;

            double dff = 0.0;
            double absd = 0.0;
            double x;
            int v = (int)(Math.Round((x_end - x_start) / x_prec, 0));

            try
            {
                for (int i = 0; i <= v; i++)
                {
                    x = x_start + x_prec * ((double)i);

                    dff += (this_sqr.eval(x) - sqref.eval(x));
                    absd += Math.Abs(this_sqr.eval(x) - sqref.eval(x));
                }
            }
            catch (ArithmeticException)
            {
                failed = true;
                score = double.PositiveInfinity;
            }

            true_score = absd;
            complex_score = GetComplexity();
            score = absd + complex_score / 10.0;
            difference = dff;

            if (double.IsNaN(score))
                score = double.PositiveInfinity;
        }

        public double eval(double x)
        {
            if (!unary && (left == null || right == null))
            {
                throw new ArgumentException("Binary Operator has one or more null parameters");
            }

            if (type == expr_type.constant)
            {
                return(EvalUnary((d => d), x));
            }
            else if (type == expr_type.exp)
            {
                return(EvalUnary(Math.Exp, x));
            }
            else if (type == expr_type.ln)
            {
                return(EvalUnary(Math.Log, x));
            }
            else if (type == expr_type.neg)
            {
                return(EvalUnary((d => -d), x));
            }
            else if (type == expr_type.recip)
            {
                return(EvalUnary((d => 1 / d), x));
            }
            else if (type == expr_type.cos)
            {
                return(EvalUnary(Math.Cos, x));
            }
            else if(type == expr_type.sin)
            {
                return(EvalUnary(Math.Cos, x));
            }
            else if (type == expr_type.tan)
            {
                return(EvalUnary(Math.Tan, x));
            }
            else if (type == expr_type.asin)
            {
                return(EvalUnary(Math.Asin, x));
            }
            else if (type == expr_type.acos)
            {
                return(EvalUnary(Math.Acos, x));
            }
            else if (type == expr_type.atan)
            {
                return(EvalUnary(Math.Atan, x));
            }
            else if (type == expr_type.divides)
            {
                return (left.eval(x) / right.eval(x));
            }
            else if (type == expr_type.minus)
            {
                return (left.eval(x) - right.eval(x));
            }
            else if (type == expr_type.times)
            {
                return (left.eval(x) * right.eval(x));
            }
            else if (type == expr_type.compose)
            {
                return (left.eval(right.eval(x)));
            }
            else if (type == expr_type.plus)
            {
                return (left.eval(x) + right.eval(x));
            }
            else if (type == expr_type.pow)
            {
                return (Math.Pow(left.eval(x), right.eval(x)));
            }
            else if(type == expr_type.sqrt)
            {
                return(EvalUnary(Math.Sqrt, x));
            }
            else
            {
                throw new ArgumentException("Invalid Operation");
            }
        }

        public double GetComplexity()
        {
            double temp = 1.0;

            if (left != null)
                temp += left.GetComplexity();

            if (right != null)
                temp += right.GetComplexity();

            return temp;
        }

        public double EvalUnary(UnaryFunction uf, double x)
        {
            if (double.IsNaN(val))
            {
                return (uf(x));
            }
            else
            {
                return (uf(val));
            }
        }

        public double GetScore()
        {
            return score;
        }

        public double GetDiff()
        {
            return difference;
        }

        public static bool IsUnary(expr_type type)
        {
            return (type == expr_type.ln || type == expr_type.exp || type == expr_type.sin || type == expr_type.cos ||
                type == expr_type.tan || type == expr_type.constant || type == expr_type.neg || type == expr_type.recip ||
                type == expr_type.asin || type == expr_type.acos || type == expr_type.atan || type == expr_type.sqrt);
        }

        public static int CompareScores(extree t1, extree t2)
        {
            if (t1.score == double.PositiveInfinity)
            {
                if (t2.score == double.PositiveInfinity)
                {
                    return 0;
                }
                else
                {
                    return 1;
                }
            }
            else if (t2.score == double.PositiveInfinity)
            {
                return -1;
            }
            else
            {
                return (Math.Sign(t1.score - t2.score));
            }
        }

        public static int CompareDiffs(extree t1, extree t2)
        {
            return (Math.Sign(t1.difference - t2.difference));
        }

        public override string ToString()
        {
            string temp = "";

            if (IsUnary(type))
            {
                if (type == expr_type.acos)
                    temp += "acos ";
                else if (type == expr_type.asin)
                    temp += "asin ";
                else if (type == expr_type.atan)
                    temp += "atan ";
                else if (type == expr_type.cos)
                    temp += "cos ";
                else if (type == expr_type.exp)
                    temp += "exp ";
                else if (type == expr_type.ln)
                    temp += "ln ";
                else if (type == expr_type.neg)
                    temp += "- ";
                else if (type == expr_type.recip)
                    temp += "1 ÷ ";
                else if (type == expr_type.sin)
                    temp += "sin ";
                else if (type == expr_type.tan)
                    temp += "tan ";
                else if (type == expr_type.sqrt)
                    temp += "sqrt ";

                if (double.IsNaN(val))
                    temp += "x ";
                else
                    temp += val + " ";
            }
            else
            {
                if (type == expr_type.compose)
                {
                    temp += "°";
                }
                else if (type == expr_type.divides)
                {
                    temp += "÷";
                }
                else if (type == expr_type.minus)
                {
                    temp += "-";
                }
                else if (type == expr_type.plus)
                {
                    temp += "+";
                }
                else if (type == expr_type.pow)
                {
                    temp += "^";
                }
                else if (type == expr_type.times)
                {
                    temp += "*";
                }

                temp = "(" + left.ToString() + " " + temp + " " + right.ToString() + ")";
            }

            return temp;
        }
    }

    public delegate double UnaryFunction(double inp);

    public enum expr_type
    {
        plus,
        minus,
        times,
        divides,
        pow,
        ln,
        exp,
        sin,
        cos,
        tan,
        constant,
        neg,
        recip,
        asin,
        acos,
        atan,
        compose,
        sqrt
    }
}
