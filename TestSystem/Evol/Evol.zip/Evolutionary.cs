﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestSystem.Evol
{
    public class Evolutionary
    {
        public static void RunTestbedx21()
        {
            // x ^ 2 + 1
            extree reference = new extree(expr_type.plus, 0.0);                 // +
            reference.left = new extree(expr_type.pow, 0.0);                    // ^
            reference.left.left = new extree(expr_type.constant, double.NaN);   // x
            reference.left.right = new extree(expr_type.constant, 2.0);         // 2.0
            reference.right = new extree(expr_type.constant, 1.0);              // 1.0
            


            // ExprEvolver ev = new ExprEvolver(reference, 1.1, Math.E, (Math.E - 1.1) / 100.0, 10.0, 50000);
            ExprGenr gev = new ExprGenr(reference, 0.0, 2.0, 0.02, 5.0, 10000, 3);

            //ExprOptimize oev = new ExprOptimize(reference, 0, 2, 0.02, 5.0, 10000, 1, 4);
            extree ex = gev.ProcessNSteps(10000, true);
        }

        public static void Genr()
        {
            // x ^ 2 + 1
            extree reference = new extree(expr_type.plus, 0.0);                 // +
            reference.left = new extree(expr_type.pow, 0.0);                    // ^
            reference.left.left = new extree(expr_type.constant, double.NaN);   // x
            reference.left.right = new extree(expr_type.constant, 2.0);         // 2.0
            reference.right = new extree(expr_type.constant, 1.0);              // 1.0

            ExprGenr gev = new ExprGenr(reference, 1.1, Math.E, (Math.E - 1.1) / 100.0, 5.0, 300000, 3);
            extree ex = gev.Process_Until_Terminal();

            //           SmtpClient smtp = new SmtpClient("mail.elkrapidsnet.com");
            //           MailMessage mm = new MailMessage("apeterson@burnettefoods.com", "anthonypete@gmail.com", "Results: " + DateTime.Now.ToString(), "Error Score: " + gev.best_current_score + " Expr: " + ex.ToString());
            //           smtp.Send(mm);
        }

        static void XM()
        {
            extree e = new extree(expr_type.plus, 0.0);
            e.left = new extree(expr_type.pow, 0.0);
            e.left.left = new extree(expr_type.constant, double.NaN);
            e.left.right = new extree(expr_type.constant, 2.0);
            e.right = new extree(expr_type.constant, 1.0);

            extree f = new extree(expr_type.exp, double.NaN);

            ExprMutate xm = new ExprMutate(1, 0.35, 0.01, 0.0, e, 0.0, 10.0, 0.25);
            xm.Process_Until_Terminal();
        }

        static void XP()
        {
            extree e = new extree(expr_type.plus, 0.0);
            e.left = new extree(expr_type.pow, 0.0);
            e.left.left = new extree(expr_type.constant, double.NaN);
            e.left.right = new extree(expr_type.constant, 2.0);
            e.right = new extree(expr_type.constant, 1.0);

            ExprPFit pm = new ExprPFit(0.0, 10.0, 0.25, e, 0.25, 0.1, 3, 2, -6, 6, 10000.0, 2);
            pm.Process_Until_Terminal();
        }

        static void XG()
        {
            extree e = new extree(expr_type.plus, 0.0);
            e.left = new extree(expr_type.pow, 0.0);
            e.left.left = new extree(expr_type.constant, double.NaN);
            e.left.right = new extree(expr_type.constant, 2.0);
            e.right = new extree(expr_type.constant, 1.0);

            ExprGenr g = new ExprGenr(e, 0.0, 10.0, 0.25, 0.25, Int32.MaxValue, 4);
            g.Process_Until_Terminal();
        }
    }
}
