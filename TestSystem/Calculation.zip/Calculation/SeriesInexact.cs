﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace TestSystem.Calculation
{
    public class SeriesInexact
    {
        public List<List<BigFloat>> cauchyArray;

        public void CalcQuadratic(List<BigFloat> initialTerms, int terms, string path)
        {
            StreamWriter sw = File.CreateText(path);

            cauchyArray = new List<List<BigFloat>>();
            cauchyArray.Add(null);
            cauchyArray.Add(new List<BigFloat>());

            if (initialTerms == null || initialTerms.Count == 0)
            {
                return;
            }

            for (int i = 0; i < initialTerms.Count; i++)
            {
                sw.WriteLine(initialTerms[i].ToString() + ", ");
                Console.WriteLine("a(" + i + ") = " + initialTerms[i].ToString());
                cauchyArray[1].Add(initialTerms[i]);
            }

            for (int i = 2; i < initialTerms.Count; i++)
            {
                cauchyArray.Add(new List<BigFloat>());

                for (int j = 0; j < initialTerms.Count; j++)
                {
                    cauchyArray[i].Add(CalculateCauchyTerm(cauchyArray[1], cauchyArray[i - 1], j));
                }
            }
           
            BigFloat nextval;
            int nextIndex = initialTerms.Count;
        
            while(nextIndex <= terms)
            {
                nextval = CalculateNextSeriesValue(nextIndex);
                sw.Write(nextval.ToString() + ", ");
                Console.WriteLine("a(" + nextIndex + ") = " + nextval.ToString());
                nextIndex++;
            }

            sw.Close();
        }

        public BigFloat CalculateCauchyTerm(List<BigFloat> basis, List<BigFloat> prev, int index)
        {
            if (basis.Count != prev.Count)
            {
                throw new ArgumentException("basis and prev are not the same length");
            }

            BigFloat accum;
            accum.significand = 0;
            accum.exponent = 0;

            BigFloat temp;

            for (int i = 0; i <= index; i++)
            {
                temp = basis[i] * prev[index - i];
                accum += temp;
            }

            return accum;
        }

        public BigFloat CalculateNextSeriesValue(int n)
        {
            BigFloat z;
            z.significand = 0;
            z.exponent = 0;

            // add temp zero to a val array.
            cauchyArray[1].Add(z);

            // add n'th value to each existing cauchy row.
            for (int i = 2; i < cauchyArray.Count; i++)
            {
                cauchyArray[i].Add(CalculateCauchyTerm(cauchyArray[1], cauchyArray[i - 1], n));
            }

            // add nth row.

            cauchyArray.Add(new List<BigFloat>());

            for (int j = 0; j < cauchyArray.Count; j++)
            {
                cauchyArray[n].Add(CalculateCauchyTerm(cauchyArray[1], cauchyArray[n-1], j));
            }

            BigFloat accum;
            accum.significand = 0;
            accum.exponent = 0;

            BigFloat temp;
            temp.significand = 0;
            temp.exponent = 0;

            for (int i = 2; i < n; i++)
            {
                temp = cauchyArray[1][i] * cauchyArray[i][n];
                accum += temp;
            }

            accum.exponent--;
            accum.significand = -1 * accum.significand;

            cauchyArray[1][n] = accum; 

            return accum;
        }
    }
}
